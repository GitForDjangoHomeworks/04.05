
document.querySelector("#bg-color")
.addEventListener("input", (e)=>{
    let h1 = document.createElement("h1")
    document.body.insertAdjacentElement('beforebegin', h1);
    h1.classList.add("test");
    h1.innerText = "red"
    // e.target.after(h1)
   
  document.querySelectorAll("textarea")
    e.target.previousElementSibling.style.color="red"
console.log();
})
// document.querySelector("#bg-color")
// .addEventListener("blur", (e)=>{
//    document.querySelector("select").remove();

   
  
//     e.target.previousElementSibling.style.color="red"
// console.log();
// })

